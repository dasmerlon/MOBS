#include "counting.h" //nicht aendern!

int alphabet[26]; //nicht aendern!

void count(const char* input){ // Dateiname als Input
	//Hier koennte Ihre Loesung stehen.
}


