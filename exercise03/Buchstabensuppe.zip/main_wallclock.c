/*
 * In dieser Datei soll nichts geaendert werden.
 */
#include "counting.h"
#include <time.h>

void print_alphabet() {
	printf("\n");
	for (int i = 0; i < 25; i++) {
		printf("%d,", alphabet[i]);
	}
	printf("%d\n", alphabet[25]);
}

void reset_alphabet() {
	for (int i = 0; i < 26; i++) {
		alphabet[i] = 0;
	}
}

int main(int argc, char *argv[]) {

	char *input_file = "input.txt";

	if (argc > 1) {
		input_file = argv[1];
	}
	printf("File: %s\n", input_file);


	for (int i = 0; i < 10; i++) {
		struct timeval tval_before, tval_after;

		gettimeofday(&tval_before, NULL);
		count(input_file);
		gettimeofday(&tval_after, NULL);
		print_alphabet();
		reset_alphabet();

		long usec_diff = (tval_after.tv_sec - tval_before.tv_sec) * 1000000
				+ (tval_after.tv_usec - tval_before.tv_usec);
		printf("Time elapsed: %ld.%06ld\n", (long int) (usec_diff / 1000000),
				(long int) (usec_diff % 1000000));

	}
	return 0;
}
