/*
 * In dieser Datei soll nichts geaendert werden.
 */
#include <stdio.h>
#include <stdlib.h>
extern int alphabet[26];
void count(const char*);
